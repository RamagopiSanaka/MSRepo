package com.boa.kyc.KycDockerApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KycDockerAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycDockerAppApplication.class, args);
	}

}

