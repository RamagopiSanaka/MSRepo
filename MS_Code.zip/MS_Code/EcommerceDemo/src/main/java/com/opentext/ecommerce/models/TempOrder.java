package com.opentext.ecommerce.models;

public class TempOrder {

	private String address;
	private long[] productId;
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long[] getProductId() {
		return productId;
	}
	public void setProductId(long[] productId) {
		this.productId = productId;
	}
	
	
	
}
