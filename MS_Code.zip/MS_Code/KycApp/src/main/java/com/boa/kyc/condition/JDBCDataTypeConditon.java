package com.boa.kyc.condition;

import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class JDBCDataTypeConditon implements Condition {
	@Override
	public boolean matches(ConditionContext arg0, AnnotatedTypeMetadata arg1) {
		String enableDBType = System.getProperty("dbType");
		return (enableDBType != null && enableDBType.equalsIgnoreCase("MYSQL"));
	}
}
