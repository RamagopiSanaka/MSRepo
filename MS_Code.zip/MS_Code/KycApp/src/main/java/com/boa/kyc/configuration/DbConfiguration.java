package com.boa.kyc.configuration;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;

import com.boa.kyc.condition.JDBCDataTypeConditon;
import com.boa.kyc.condition.MongoDataTypeCondition;

@Configuration
public class DbConfiguration {
	
	@Value("${datasource.url}")
	private String url;
	@Value("${datasource.username}")
	private String username;
	@Value("${datasource.password}")
	private String password;
	
	
	@Bean
	@ConditionalOnClass(DataSource.class)
	public DataSource getMySqlDataSource() {
		DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
		dataSourceBuilder.url(url);
		dataSourceBuilder.username(username);
		dataSourceBuilder.password(password);
		return dataSourceBuilder.build();
	}
	
	@Bean
	@Conditional(JDBCDataTypeConditon.class)
	public TransactionData jdbcTransaction() {
		return new JDBCTransactionImpl();
	}
	
	@Bean
	@Conditional(MongoDataTypeCondition.class)
	public TransactionData mongoTransaction() {
		return new MongoTransactionImpl();
	}
}
