package com.boa.kyc.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.boa.kyc.service.JDBCTransactionService;

public class JDBCTransactionImpl implements TransactionData {
@Autowired
private JDBCTransactionService jdbcTransactionService;

@Override
public List getAllTransactions() {
	return jdbcTransactionService.getAllTransactions();
}

}
