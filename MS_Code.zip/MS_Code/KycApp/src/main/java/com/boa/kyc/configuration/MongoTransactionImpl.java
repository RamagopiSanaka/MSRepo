package com.boa.kyc.configuration;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.boa.kyc.service.JDBCTransactionService;
import com.boa.kyc.service.MongoTransactionService;

public class MongoTransactionImpl implements TransactionData {
@Autowired
private MongoTransactionService mongoTransactionService;

@Override
public List getAllTransactions() {
	return mongoTransactionService.getAllTransactions();
}

}
