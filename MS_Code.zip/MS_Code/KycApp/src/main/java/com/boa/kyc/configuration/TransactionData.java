package com.boa.kyc.configuration;

import java.util.List;

public interface TransactionData {
	public List getAllTransactions();
}
