package com.boa.kyc.configuration;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.boa.kyc.filter.TransactionFilter;
import com.boa.kyc.filter.TransactionFilter2;

@Configuration
public class TransactionFilterRegistration {
	@Bean
	public FilterRegistrationBean<TransactionFilter> registerFilter() {
		FilterRegistrationBean<TransactionFilter> filterRegistrationBean = new FilterRegistrationBean<TransactionFilter>();
		TransactionFilter transactionFilter = new TransactionFilter();
		filterRegistrationBean.setFilter(transactionFilter);
		filterRegistrationBean.addUrlPatterns("/transaction/*");
		filterRegistrationBean.setOrder(1);
		return filterRegistrationBean;
	}
	
	@Bean
	public FilterRegistrationBean<TransactionFilter2> registerFilter2() {
		FilterRegistrationBean<TransactionFilter2> filterRegistrationBean = new FilterRegistrationBean<TransactionFilter2>();
		TransactionFilter2 transactionFilter = new TransactionFilter2();
		filterRegistrationBean.setFilter(transactionFilter);
		filterRegistrationBean.addUrlPatterns("/transaction/*");
		filterRegistrationBean.setOrder(2);
		return filterRegistrationBean;
	}
	
}
