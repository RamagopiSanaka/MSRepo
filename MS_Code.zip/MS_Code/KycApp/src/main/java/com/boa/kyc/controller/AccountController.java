package com.boa.kyc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.modal.Account;
import com.boa.kyc.service.AccountService;

@RestController
public class AccountController {

	@Autowired
	private AccountService accountService;

	@CrossOrigin("*")
	@PostMapping("/addAccount/{customerId}")
	public @ResponseBody Account addAccount(@RequestBody Account account, @PathVariable int customerId) {
		return accountService.addAccount(account, customerId);
	}

	@CrossOrigin("*")
	@GetMapping("/getAccountById/{accountId}")
	public @ResponseBody Account getAccountById(@PathVariable int accountId) {

		return accountService.getAccountById(accountId);
	}

	@CrossOrigin("*")
	@GetMapping("/getAllAccounts")
	public @ResponseBody List<Account> getAllAccounts() {

		return accountService.getAllAccounts();
	}
}
