package com.boa.kyc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.configuration.DbConfiguration;
import com.boa.kyc.modal.Customer;
import com.boa.kyc.service.CustomerService;

@RestController
public class CustomerController {

	@Value("${message}")
	private String message;
	
	@Autowired
	private DbConfiguration dbConfiguration;
	
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/conditionalTest")
	public List getAllTransactions() {
		System.out.println("AmlKyc :: "+message);
		return dbConfiguration.mongoTransaction().getAllTransactions();
	}

	// add Customer
	@CrossOrigin("*") // access b/w domains
	@PostMapping("/addCustomer")
	public @ResponseBody Customer addCustomer(@RequestBody Customer customer) {

		return this.customerService.addCustomer(customer);
	}

	// get All Customers
	@CrossOrigin("*") // access b/w domains
	@GetMapping("/getAllCustomers")
	public @ResponseBody List<Customer> getAllCustomers() {
		return this.customerService.getAllCustomers();
	}

	// get Customer By Id
	@CrossOrigin("*") // access b/w domains
	@GetMapping("/getCustomerById/{id}")
	public @ResponseBody Customer getCustomerById(@PathVariable int id) {
		return this.customerService.getCustomerById(id);
	}

	// get Customer By Id
	@CrossOrigin("*") // access b/w domains
	@GetMapping("/deleteCustomerById/{id}")
	public void deleteCustomerById(@PathVariable int id) {
		this.customerService.deleteCustomerById(id);
	}

	// update Customer
	@CrossOrigin("*")
	@GetMapping("/updateCustomer/{id}/{firstName}")
	public void updateCustomer(@PathVariable int id, @PathVariable String firstName) {
		this.customerService.updateCustomer(id, firstName);
	}

	@CrossOrigin("*")
	@PutMapping("/updateCustomerById/{id}")
	public Customer updateCustomerById(@PathVariable int id, @RequestBody Customer customer) {
		Customer cust = this.customerService.getCustomerById(id);
		cust.setFirstName(customer.getFirstName());
		cust.setLastName(customer.getLastName());
		cust.setDob(customer.getDob());
		cust.setAddress(customer.getAddress());
		return this.customerService.addCustomer(cust);
	}

}
