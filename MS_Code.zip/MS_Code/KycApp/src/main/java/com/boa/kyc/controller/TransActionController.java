package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.boa.kyc.modal.MongoTransaction;
import com.boa.kyc.service.MongoTransactionService;

@Controller
public class TransActionController {

	@Autowired
	private MongoTransactionService service;
	
	@RequestMapping("/transaction")
	public String loadHome(Model model) {
		model.addAttribute("transactionList",service.getAllTransactions());
		return "home";
	}
	@RequestMapping(value="/addTransaction",method=RequestMethod.POST)
	public String  createTransactionData(@ModelAttribute MongoTransaction transaction) {
		service.addTransaction(transaction);
		return "redirect:transaction";
	}
}
