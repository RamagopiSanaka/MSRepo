package com.boa.kyc.filter;

import java.io.IOException;
import java.util.Random;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.logging.Logger;
import org.springframework.boot.ExitCodeGenerator;

public class TransactionFilter implements javax.servlet.Filter, ExitCodeGenerator {

	private static final Logger LOGGER = Logger.getLogger(TransactionFilter.class);
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain)
			throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest)request;
		HttpServletResponse httpResponse = (HttpServletResponse)response;
		LOGGER.info("TransactionFilter :: Inside doFilter()");
		/*if(request.getRemoteHost().equals("0:0:0:0:0:0:0:1")) {
			throw new RuntimeException("Exit Code : "+getExitCode());
		}*/
		
		filterChain.doFilter(httpRequest, httpResponse);
	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		Filter.super.init(filterConfig);
		LOGGER.info("TransactionFilter :: Inside init()");
	}
	
	@Override
	public void destroy() {
		Filter.super.destroy();
		LOGGER.info("TransactionFilter :: Inside destroy()");
	}

	@Override
	public int getExitCode() {
		return new Random().nextInt(1000);
	}
}
