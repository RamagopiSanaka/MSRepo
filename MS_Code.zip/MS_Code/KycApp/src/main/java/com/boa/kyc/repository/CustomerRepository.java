package com.boa.kyc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.boa.kyc.modal.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
	@Modifying(clearAutomatically = true)
	@Query("update Customer set firstName=:firstName where id=:id")
	public void updateCustomer(@Param("id") int id, @Param("firstName") String firstName);

}
