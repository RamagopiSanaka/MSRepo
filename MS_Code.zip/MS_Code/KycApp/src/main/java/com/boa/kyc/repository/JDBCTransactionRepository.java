package com.boa.kyc.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.boa.kyc.modal.JDBCTransaction;
@Repository
public interface JDBCTransactionRepository extends JpaRepository<JDBCTransaction, Integer> {

}
