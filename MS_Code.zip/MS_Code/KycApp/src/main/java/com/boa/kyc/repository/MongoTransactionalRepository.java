package com.boa.kyc.repository;

import javax.transaction.Transactional;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.boa.kyc.modal.MongoTransaction;

@Transactional
public interface MongoTransactionalRepository extends MongoRepository<MongoTransaction, Integer>{

}
