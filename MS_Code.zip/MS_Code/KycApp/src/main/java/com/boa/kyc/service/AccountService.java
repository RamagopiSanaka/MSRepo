package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.modal.Account;
import com.boa.kyc.modal.Customer;
import com.boa.kyc.repository.AccountRepository;

@Service
public class AccountService {

	@Autowired
	private AccountRepository accountRepository;

	@Autowired
	private CustomerService customerService;

	public Account addAccount(Account account, int customerId) {
		Customer customer = customerService.getCustomerById(customerId);
		account.setCustomer(customer);
		return accountRepository.save(account);
	}

	public Account getAccountById(int accountId) {
		return accountRepository.findById(accountId).orElse(null);
	}

	public List<Account> getAllAccounts() {
		return accountRepository.findAll();
	}
}
