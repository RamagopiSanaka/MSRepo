package com.boa.kyc.service;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.modal.Customer;
import com.boa.kyc.repository.CustomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CustomerRepository customerRepository;

	// add Customer
	public Customer addCustomer(Customer customer) {
		return customerRepository.save(customer);
	}

	// customer by Id
	public Customer getCustomerById(int id) {
		return customerRepository.findById(id).orElse(null);
	}
	
	//get all Customers
	public List<Customer> getAllCustomers(){
		return customerRepository.findAll();
	}
	
	//delete Customer
	public void deleteCustomerById(int id) {
		customerRepository.deleteById(id);
	}
	
	//update Customer
	@Transactional(value=TxType.REQUIRED)
	public void updateCustomer(int id, String firstName) {
		customerRepository.updateCustomer(id, firstName);
	}
}
