package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.modal.JDBCTransaction;
import com.boa.kyc.repository.JDBCTransactionRepository;

@Service
public class JDBCTransactionService {

	@Autowired
	private JDBCTransactionRepository jdbcTransactionRepository;

	public JDBCTransaction addTransaction(JDBCTransaction jdbcTransaction) {
		return jdbcTransactionRepository.save(jdbcTransaction);
	}

	public List<JDBCTransaction> getAllTransactions() {
		return jdbcTransactionRepository.findAll();
	}
}
