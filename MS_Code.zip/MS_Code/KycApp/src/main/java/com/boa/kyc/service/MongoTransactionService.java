package com.boa.kyc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.modal.MongoTransaction;
import com.boa.kyc.repository.MongoTransactionalRepository;
@Service
public class MongoTransactionService {

	@Autowired
	private MongoTransactionalRepository mongoTransactionalRepository;
	public List<MongoTransaction> getAllTransactions( ) {
		return mongoTransactionalRepository.findAll();
		
	}

	public MongoTransaction addTransaction(MongoTransaction transaction) {
		return mongoTransactionalRepository.save(transaction);
		
	}

}
