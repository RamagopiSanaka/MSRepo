package com.boa.kyc.security;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

public class CustomerVerification implements UserDetailsService {

	private static List<KycUser> users = new ArrayList();

	public CustomerVerification() {
		users.add(new KycUser("user1", "123", "ADMIN"));
		users.add(new KycUser("user2", "234", "USER"));
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<KycUser> result = users.stream().filter(u -> u.getUserName().equals(username)).findAny();
		if (!result.isPresent()) {
			throw new UsernameNotFoundException("User not found by name: " + username);
		}
		return toUserDetails(result.get());
	}

	 private UserDetails toUserDetails(KycUser userObject) {
	    	PasswordEncoder encoder =new BCryptPasswordEncoder();
	        return User.withUsername(userObject.getUserName())
	                   .password(encoder.encode(userObject.getPassword()))
	                   .roles(userObject.getRole()).build();
	    }

}
