package com.boa.kyc.KycConfigClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = "com.boa.kyc.*")
public class KycConfigClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycConfigClientApplication.class, args);
	}

}

