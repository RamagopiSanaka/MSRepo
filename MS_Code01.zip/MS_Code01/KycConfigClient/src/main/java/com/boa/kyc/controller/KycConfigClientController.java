package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RefreshScope
@RestController
public class KycConfigClientController {

	@Value("${text.copyright: Ramagopi Copyright}")
	private String copyright;
	
	@Value("${msg}")
	private String msg;

	@Value("${spring.datasource.driver-class-name}")
	private String driverClassName;

	@Value("${spring.datasource.url}")
	private String url;

	@Value("${spring.datasource.userName}")
	private String userName;

	@Value("${spring.datasource.password}")
	private String password;

	@GetMapping("/getConfigProps")
	@ResponseBody
	public String getConfigProps() {
		String configProps = "Message : " + msg
				+ "<br/> Copyright &copy; "+copyright
				+"<br/> spring.datasource.driver-class-name : " + driverClassName
				+"<br/> spring.datasource.url=jdbc : " + url
				+"<br/> spring.datasource.userName : " + userName
				+"<br/> spring.datasource.password : "+ password;
		return configProps;
	}
}
