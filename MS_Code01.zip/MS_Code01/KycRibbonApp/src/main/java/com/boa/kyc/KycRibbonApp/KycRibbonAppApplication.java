package com.boa.kyc.KycRibbonApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@SpringBootApplication
@EnableFeignClients(basePackages="com.boa.kyc.*")
@ComponentScan(basePackages="com.boa.kyc.*")
public class KycRibbonAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(KycRibbonAppApplication.class, args);
	}

}

