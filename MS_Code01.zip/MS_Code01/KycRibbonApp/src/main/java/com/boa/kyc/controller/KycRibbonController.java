package com.boa.kyc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.repository.KycRibbonRepository;

@RestController
public class KycRibbonController {

	@Autowired
	private KycRibbonRepository kycRibbonRepository;
	
	@GetMapping("/getCustomData")
	public String getFeignCustomData() {
		ResponseEntity<String> responseEntity = kycRibbonRepository.retriveAssests();
		return responseEntity.getBody();
	}
}
