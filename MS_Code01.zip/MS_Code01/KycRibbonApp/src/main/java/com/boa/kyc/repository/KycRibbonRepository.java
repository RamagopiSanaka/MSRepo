package com.boa.kyc.repository;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import com.boa.kyc.client.KycRibbonClient;

//KycApp is same as prop's   KycApp.ribbon.listOfServers
@FeignClient(name = "KycApp", configuration = KycRibbonClient.class)
@RibbonClient(name = "KycApp")
public interface KycRibbonRepository {

	@GetMapping("/getAllCustomers")
	public ResponseEntity<String> retriveAssests();
}
